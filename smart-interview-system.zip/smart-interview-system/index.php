<?php
// Landing page
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Interview Preparation System</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="hero">
    <div class="badge">Placement-ready Interview Training</div>
    <h1 class="hero-title">Smart Interview Preparation System</h1>
    <p class="hero-subtitle">
        A modern, dashboard-driven platform for students to practice interview-style MCQs,
        track their performance, and for administrators to manage questions and results.
    </p>

    <div class="hero-actions">
        <a href="student/login.php" class="btn btn-primary">
            Student Login
        </a>
        <a href="student/register.php" class="btn btn-outline">
            Student Registration
        </a>
        <a href="admin/login.php" class="btn btn-outline">
            Admin Login
        </a>
    </div>
</div>
</body>
</html>